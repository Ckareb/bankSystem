--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.0
-- Dumped by pg_dump version 17.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE banksystem;
--
-- Name: banksystem; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE banksystem WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Russian_Russia.1251';


ALTER DATABASE banksystem OWNER TO postgres;

\connect banksystem

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: block_access(); Type: FUNCTION; Schema: public; Owner: username
--

CREATE FUNCTION public.block_access() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN   RAISE EXCEPTION 'Access to this table is blocked';   RETURN NULL; END; $$;


ALTER FUNCTION public.block_access() OWNER TO username;

--
-- Name: read_only_table(); Type: FUNCTION; Schema: public; Owner: username
--

CREATE FUNCTION public.read_only_table() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN   RAISE EXCEPTION 'Table is read-only';   RETURN NULL; END; $$;


ALTER FUNCTION public.read_only_table() OWNER TO username;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accounts; Type: TABLE; Schema: public; Owner: username
--

CREATE TABLE public.accounts (
    id integer NOT NULL,
    nameaccount character varying DEFAULT 20 NOT NULL,
    namebank character varying(255) NOT NULL,
    typeaccount character varying(50),
    opendate character varying(50),
    accountcurrency character varying(10),
    customer_id integer NOT NULL
);

ALTER TABLE ONLY public.accounts FORCE ROW LEVEL SECURITY;


ALTER TABLE public.accounts OWNER TO username;

--
-- Name: accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: username
--

CREATE SEQUENCE public.accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.accounts_id_seq OWNER TO username;

--
-- Name: accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: username
--

ALTER SEQUENCE public.accounts_id_seq OWNED BY public.accounts.id;


--
-- Name: archive_moneyaccount_32132132132132132121; Type: TABLE; Schema: public; Owner: username
--

CREATE TABLE public.archive_moneyaccount_32132132132132132121 (
    id integer NOT NULL,
    nameaccount character varying(20) NOT NULL,
    historyaccount character varying(256) NOT NULL,
    timechange timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    countaccount double precision NOT NULL
);


ALTER TABLE public.archive_moneyaccount_32132132132132132121 OWNER TO username;

--
-- Name: archive_moneyaccount_32132132132132132121_id_seq; Type: SEQUENCE; Schema: public; Owner: username
--

CREATE SEQUENCE public.archive_moneyaccount_32132132132132132121_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.archive_moneyaccount_32132132132132132121_id_seq OWNER TO username;

--
-- Name: archive_moneyaccount_32132132132132132121_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: username
--

ALTER SEQUENCE public.archive_moneyaccount_32132132132132132121_id_seq OWNED BY public.archive_moneyaccount_32132132132132132121.id;


--
-- Name: archived_account; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.archived_account (
    id integer NOT NULL,
    nameaccount character varying(255) NOT NULL,
    namebank character varying(255) NOT NULL,
    typeaccount character varying(100),
    opendate character varying(100),
    accountcurrency character varying(10),
    customer_id integer,
    archived_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.archived_account OWNER TO postgres;

--
-- Name: archived_account_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.archived_account_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.archived_account_id_seq OWNER TO postgres;

--
-- Name: archived_account_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.archived_account_id_seq OWNED BY public.archived_account.id;


--
-- Name: customers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customers (
    id integer NOT NULL,
    name character varying(30),
    birthday character varying(100),
    citybirths character varying(100),
    seriesnumberpassport character varying DEFAULT 20,
    whygive character varying(100),
    giveday character varying(100)
);


ALTER TABLE public.customers OWNER TO postgres;

--
-- Name: customers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.customers_id_seq OWNER TO postgres;

--
-- Name: customers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customers_id_seq OWNED BY public.customers.id;


--
-- Name: moneyaccount_12345678912345678912; Type: TABLE; Schema: public; Owner: username
--

CREATE TABLE public.moneyaccount_12345678912345678912 (
    id integer NOT NULL,
    nameaccount character varying(20) NOT NULL,
    historyaccount character varying(256) NOT NULL,
    timechange timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    countaccount double precision NOT NULL
);


ALTER TABLE public.moneyaccount_12345678912345678912 OWNER TO username;

--
-- Name: moneyaccount_12345678912345678912_id_seq; Type: SEQUENCE; Schema: public; Owner: username
--

CREATE SEQUENCE public.moneyaccount_12345678912345678912_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.moneyaccount_12345678912345678912_id_seq OWNER TO username;

--
-- Name: moneyaccount_12345678912345678912_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: username
--

ALTER SEQUENCE public.moneyaccount_12345678912345678912_id_seq OWNED BY public.moneyaccount_12345678912345678912.id;


--
-- Name: moneyaccount_33213214321432144121; Type: TABLE; Schema: public; Owner: username
--

CREATE TABLE public.moneyaccount_33213214321432144121 (
    id integer NOT NULL,
    nameaccount character varying(20) NOT NULL,
    historyaccount character varying(256) NOT NULL,
    timechange timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    countaccount double precision NOT NULL
);


ALTER TABLE public.moneyaccount_33213214321432144121 OWNER TO username;

--
-- Name: moneyaccount_33213214321432144121_id_seq; Type: SEQUENCE; Schema: public; Owner: username
--

CREATE SEQUENCE public.moneyaccount_33213214321432144121_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.moneyaccount_33213214321432144121_id_seq OWNER TO username;

--
-- Name: moneyaccount_33213214321432144121_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: username
--

ALTER SEQUENCE public.moneyaccount_33213214321432144121_id_seq OWNED BY public.moneyaccount_33213214321432144121.id;


--
-- Name: accounts id; Type: DEFAULT; Schema: public; Owner: username
--

ALTER TABLE ONLY public.accounts ALTER COLUMN id SET DEFAULT nextval('public.accounts_id_seq'::regclass);


--
-- Name: archive_moneyaccount_32132132132132132121 id; Type: DEFAULT; Schema: public; Owner: username
--

ALTER TABLE ONLY public.archive_moneyaccount_32132132132132132121 ALTER COLUMN id SET DEFAULT nextval('public.archive_moneyaccount_32132132132132132121_id_seq'::regclass);


--
-- Name: archived_account id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.archived_account ALTER COLUMN id SET DEFAULT nextval('public.archived_account_id_seq'::regclass);


--
-- Name: customers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers ALTER COLUMN id SET DEFAULT nextval('public.customers_id_seq'::regclass);


--
-- Name: moneyaccount_12345678912345678912 id; Type: DEFAULT; Schema: public; Owner: username
--

ALTER TABLE ONLY public.moneyaccount_12345678912345678912 ALTER COLUMN id SET DEFAULT nextval('public.moneyaccount_12345678912345678912_id_seq'::regclass);


--
-- Name: moneyaccount_33213214321432144121 id; Type: DEFAULT; Schema: public; Owner: username
--

ALTER TABLE ONLY public.moneyaccount_33213214321432144121 ALTER COLUMN id SET DEFAULT nextval('public.moneyaccount_33213214321432144121_id_seq'::regclass);


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: username
--

COPY public.accounts (id, nameaccount, namebank, typeaccount, opendate, accountcurrency, customer_id) FROM stdin;
\.
COPY public.accounts (id, nameaccount, namebank, typeaccount, opendate, accountcurrency, customer_id) FROM '$$PATH$$/4852.dat';

--
-- Data for Name: archive_moneyaccount_32132132132132132121; Type: TABLE DATA; Schema: public; Owner: username
--

COPY public.archive_moneyaccount_32132132132132132121 (id, nameaccount, historyaccount, timechange, countaccount) FROM stdin;
\.
COPY public.archive_moneyaccount_32132132132132132121 (id, nameaccount, historyaccount, timechange, countaccount) FROM '$$PATH$$/4860.dat';

--
-- Data for Name: archived_account; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.archived_account (id, nameaccount, namebank, typeaccount, opendate, accountcurrency, customer_id, archived_at) FROM stdin;
\.
COPY public.archived_account (id, nameaccount, namebank, typeaccount, opendate, accountcurrency, customer_id, archived_at) FROM '$$PATH$$/4858.dat';

--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customers (id, name, birthday, citybirths, seriesnumberpassport, whygive, giveday) FROM stdin;
\.
COPY public.customers (id, name, birthday, citybirths, seriesnumberpassport, whygive, giveday) FROM '$$PATH$$/4850.dat';

--
-- Data for Name: moneyaccount_12345678912345678912; Type: TABLE DATA; Schema: public; Owner: username
--

COPY public.moneyaccount_12345678912345678912 (id, nameaccount, historyaccount, timechange, countaccount) FROM stdin;
\.
COPY public.moneyaccount_12345678912345678912 (id, nameaccount, historyaccount, timechange, countaccount) FROM '$$PATH$$/4856.dat';

--
-- Data for Name: moneyaccount_33213214321432144121; Type: TABLE DATA; Schema: public; Owner: username
--

COPY public.moneyaccount_33213214321432144121 (id, nameaccount, historyaccount, timechange, countaccount) FROM stdin;
\.
COPY public.moneyaccount_33213214321432144121 (id, nameaccount, historyaccount, timechange, countaccount) FROM '$$PATH$$/4854.dat';

--
-- Name: accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: username
--

SELECT pg_catalog.setval('public.accounts_id_seq', 42, true);


--
-- Name: archive_moneyaccount_32132132132132132121_id_seq; Type: SEQUENCE SET; Schema: public; Owner: username
--

SELECT pg_catalog.setval('public.archive_moneyaccount_32132132132132132121_id_seq', 12, true);


--
-- Name: archived_account_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.archived_account_id_seq', 5, true);


--
-- Name: customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customers_id_seq', 13, true);


--
-- Name: moneyaccount_12345678912345678912_id_seq; Type: SEQUENCE SET; Schema: public; Owner: username
--

SELECT pg_catalog.setval('public.moneyaccount_12345678912345678912_id_seq', 4, true);


--
-- Name: moneyaccount_33213214321432144121_id_seq; Type: SEQUENCE SET; Schema: public; Owner: username
--

SELECT pg_catalog.setval('public.moneyaccount_33213214321432144121_id_seq', 4, true);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: username
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- Name: archive_moneyaccount_32132132132132132121 archive_moneyaccount_32132132132132132121_pkey; Type: CONSTRAINT; Schema: public; Owner: username
--

ALTER TABLE ONLY public.archive_moneyaccount_32132132132132132121
    ADD CONSTRAINT archive_moneyaccount_32132132132132132121_pkey PRIMARY KEY (id);


--
-- Name: archived_account archived_account_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.archived_account
    ADD CONSTRAINT archived_account_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: moneyaccount_12345678912345678912 moneyaccount_12345678912345678912_pkey; Type: CONSTRAINT; Schema: public; Owner: username
--

ALTER TABLE ONLY public.moneyaccount_12345678912345678912
    ADD CONSTRAINT moneyaccount_12345678912345678912_pkey PRIMARY KEY (id);


--
-- Name: moneyaccount_33213214321432144121 moneyaccount_33213214321432144121_pkey; Type: CONSTRAINT; Schema: public; Owner: username
--

ALTER TABLE ONLY public.moneyaccount_33213214321432144121
    ADD CONSTRAINT moneyaccount_33213214321432144121_pkey PRIMARY KEY (id);


--
-- Name: accounts unique_name_account; Type: CONSTRAINT; Schema: public; Owner: username
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT unique_name_account UNIQUE (nameaccount);


--
-- Name: archived_account unique_nameaccount; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.archived_account
    ADD CONSTRAINT unique_nameaccount UNIQUE (nameaccount);


--
-- Name: customers unique_seriesnumberpassport; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT unique_seriesnumberpassport UNIQUE (seriesnumberpassport);


--
-- Name: moneyaccount_33213214321432144121 block_all_access; Type: TRIGGER; Schema: public; Owner: username
--

CREATE TRIGGER block_all_access BEFORE INSERT OR DELETE OR UPDATE ON public.moneyaccount_33213214321432144121 FOR EACH ROW EXECUTE FUNCTION public.block_access();


--
-- Name: accounts fk_customer; Type: FK CONSTRAINT; Schema: public; Owner: username
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT fk_customer FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: moneyaccount_12345678912345678912 moneyaccount_12345678912345678912_nameaccount_fkey; Type: FK CONSTRAINT; Schema: public; Owner: username
--

ALTER TABLE ONLY public.moneyaccount_12345678912345678912
    ADD CONSTRAINT moneyaccount_12345678912345678912_nameaccount_fkey FOREIGN KEY (nameaccount) REFERENCES public.accounts(nameaccount) ON DELETE RESTRICT;


--
-- Name: moneyaccount_33213214321432144121 moneyaccount_33213214321432144121_nameaccount_fkey; Type: FK CONSTRAINT; Schema: public; Owner: username
--

ALTER TABLE ONLY public.moneyaccount_33213214321432144121
    ADD CONSTRAINT moneyaccount_33213214321432144121_nameaccount_fkey FOREIGN KEY (nameaccount) REFERENCES public.accounts(nameaccount) ON DELETE RESTRICT;


--
-- Name: accounts block_account_policy; Type: POLICY; Schema: public; Owner: username
--

CREATE POLICY block_account_policy ON public.accounts USING (((nameaccount)::text <> '32132132132132132121'::text));


--
-- Name: DATABASE banksystem; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON DATABASE banksystem TO username;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT CREATE ON SCHEMA public TO username;


--
-- Name: TABLE archived_account; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.archived_account TO username;


--
-- Name: SEQUENCE archived_account_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,USAGE ON SEQUENCE public.archived_account_id_seq TO username;


--
-- Name: TABLE customers; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.customers TO username;


--
-- Name: SEQUENCE customers_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,USAGE ON SEQUENCE public.customers_id_seq TO username;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO username;


--
-- PostgreSQL database dump complete
--

