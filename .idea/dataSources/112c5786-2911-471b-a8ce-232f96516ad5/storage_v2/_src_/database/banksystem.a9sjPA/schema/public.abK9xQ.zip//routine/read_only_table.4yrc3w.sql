create function read_only_table() returns trigger
    language plpgsql
as
$$ BEGIN   RAISE EXCEPTION 'Table is read-only';   RETURN NULL; END; $$;

alter function read_only_table() owner to username;

