create function block_access() returns trigger
    language plpgsql
as
$$ BEGIN   RAISE EXCEPTION 'Access to this table is blocked';   RETURN NULL; END; $$;

alter function block_access() owner to username;

